library(frustratometeR)
PdbsDir <- "/gpfs/scratch/bsc08/bsc08453/postdoc/frustration_analysis/NSP3_cd21732_betaCoV_PLPro/frustraevo_output_allmodels/cluster3/OutPutFilesNSP3_cd21732_betaCoV_PLPro_cluster3/Frustration/"
ResultsDir <- "/gpfs/scratch/bsc08/bsc08453/postdoc/frustration_analysis/NSP3_cd21732_betaCoV_PLPro/frustraevo_output_allmodels/cluster3/OutPutFilesNSP3_cd21732_betaCoV_PLPro_cluster3/Frustration/"
dir_frustration(PdbsDir = PdbsDir, Mode = "singleresidue", ResultsDir = ResultsDir)
