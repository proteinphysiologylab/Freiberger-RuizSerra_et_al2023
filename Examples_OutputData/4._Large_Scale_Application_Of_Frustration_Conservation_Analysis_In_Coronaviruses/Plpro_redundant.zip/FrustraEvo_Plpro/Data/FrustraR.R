library(frustratometeR)
PdbsDir <- '/home/maria/Documentos/EvoFrustra/FrustraEvo_Plpro/Frustration/'
ResultsDir <- '/home/maria/Documentos/EvoFrustra/FrustraEvo_Plpro/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'singleresidue', ResultsDir = ResultsDir)
