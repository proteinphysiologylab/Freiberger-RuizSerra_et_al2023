library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_2023719101038158741/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_2023719101038158741/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir,Graphics = FALSE)
