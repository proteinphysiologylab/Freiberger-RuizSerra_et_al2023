library(frustratometeR)
PdbsDir <- '/root/FrustraEvo/FrustraEvo_20237181515717941/Frustration/'
ResultsDir <- '/root/FrustraEvo/FrustraEvo_20237181515717941/Frustration/'
dir_frustration(PdbsDir = PdbsDir, Mode = 'configurational', ResultsDir = ResultsDir,Graphics = FALSE)
